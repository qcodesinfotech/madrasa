<?php

namespace App\Http\Controllers;

use App\Models\Attendance;
use App\Models\Student;
use App\Models\Syllabus_type;
use App\Models\Structure;
use App\Models\Course;
use App\Models\Pre_end;
use App\Models\Syllabus_add;
use App\Models\syllabus;
use App\Models\Teacher;
use Illuminate\Http\Request;

use  Illuminate\Support\Carbon;
use Carbon\CarbonPeriod;
use Illuminate\Support\Facades\DB;

class StudentController extends Controller
{
    public function index()
    {
        $course = DB::table('syllabus_types')->get();
        $student =  DB::table('students')
            ->join('syllabus_types', 'syllabus_types.id', 'students.course_id')
            ->select('students.*', 'syllabus_types.title as course')
            ->get();
        return view('student.index', compact('student', 'course'));
    }
    public function searchstudent(Request $request)
    {
        $course = DB::table('syllabus_types')->get();
        $student1 =  DB::table('students')
            ->where(DB::raw('lower(students.name)'), 'like', '%' . strtolower($request->student) . '%')
            ->join('syllabus_types', 'syllabus_types.id', 'students.course_id')
            ->select('students.*', 'syllabus_types.title as course')
            ->get();
        if (sizeof($student1) > 0) {
            return view('student.index', compact('student1', 'course'));
        } else {
            return redirect()->route('student.index')
                ->with('success', '0 result  found');
        }
    }


    public function store(Request $request)
    {




        $request->validate([
            'name' => 'required|unique:students,name',
        ]);
        $dist = $request['district'];
        $state = $request['state'];
        $pincode = $request['pincode'];
        $city = $request['city'];
        $address = $dist . "," . $state . "," . $city . "," . $pincode;
        $question = new Student;
        $question->name = $request->get('name');
        $question->admission_no = $request->get('admission_no');
        $question->father_name = $request->get('father_name');
        $question->father_occupation = $request->get('father_occupation');
        $question->date_of_birth = $request->get('date_of_birth');
        $question->address = $address;
        $question->aadhar_no = $request->get('aadhar_no');
        $question->course_id = $request->get('course');
        $question->mobile_no = $request->get('mobile_no');
        $question->whatsapp_no = $request->get('whatsapp_no');
        $question->monthly_donation = $request->get('monthly_donation');
        $question->blood_group = $request->get('blood_group');
        $question->admission_date = $request->get('admission_date');
        $question->previous_school = $request->get('previous_school');




        if ($request->file('proof1')) {

            $file = $request->file('proof1');
            $destinationPath = 'students_photo/';
            $profileImage1 = date('YmdHis') . "." . $file->getClientOriginalExtension();
            $file->move($destinationPath, $profileImage1);
            $question['proof1'] = $profileImage1;
        }

        if ($request->file('proof2')) {

            $file = $request->file('proof2');
            $destinationPath = 'students_photo/';
            $profileImage1 = date('YmdHis') . "." . $file->getClientOriginalExtension();
            $file->move($destinationPath, $profileImage1);
            $question['proof2'] = $profileImage1;
        }

        if ($request->file('proof3')) {

            $file = $request->file('proof3');
            $destinationPath = 'students_photo/';
            $profileImage2 = date('YmdHis') . "." . $file->getClientOriginalExtension();
            $file->move($destinationPath, $profileImage2);
            $question['proof3'] = $profileImage2;
        }

        if ($request->file('proof4')) {

            $file = $request->file('proof4');
            $destinationPath = 'students_photo/';
            $profileImage3 = date('YmdHis') . "." . $file->getClientOriginalExtension();
            $file->move($destinationPath, $profileImage3);
            $question['proof4'] = $profileImage3;
        }

        if ($request->file('proof5')) {

            $file = $request->file('proof5');
            $destinationPath = 'students_photo/';
            $profileImage4 = date('YmdHis') . "." . $file->getClientOriginalExtension();
            $file->move($destinationPath, $profileImage4);
            $question['proof5'] = $profileImage4;
        }
        if ($request->file('proof6')) {

            $file = $request->file('proof6');
            $destinationPath = 'students_photo/';
            $profileImage5 = date('YmdHis') . "." . $file->getClientOriginalExtension();
            $file->move($destinationPath, $profileImage5);
            $question['proof6'] = $profileImage5;
        }



        if ($request->file('student_pic')) {

            $file = $request->file('student_pic');
            $destinationPath = 'students_photo/';
            $profileImage6 = date('YmdHis') . "." . $file->getClientOriginalExtension();
            $file->move($destinationPath, $profileImage6);
            $question['student_pic'] = $profileImage6;
        }

        $question->save();
        return redirect()->route('student.index')
            ->with('success', 'student list created successfully.');
    }
    public function edit(Student $student)
    {
        $course = DB::table('syllabus_types')->get();
        $students =  DB::table('students')
            ->where('students.id', '=', $student->id)
            ->join('syllabus_types', 'syllabus_types.id', 'students.course_id')
            ->select('students.*', 'syllabus_types.title as course')
            ->get();
        foreach ($students as $student) {
            return view('student.edit', compact('student', 'course'));
        }
    }
    public function update(Request $request, $id)
    {


        
        $question = Student::find($id);
        $question->name = $request->get('name');
        $question->admission_no = $request->get('admission_no');
        $question->father_name = $request->get('father_name');
        $question->father_occupation = $request->get('father_occupation');
        $question->date_of_birth = $request->get('date_of_birth');
        $question->aadhar_no = $request->get('aadhar_no');
        $question->course_id = $request->get('course');
        $question->mobile_no = $request->get('mobile_no');
        $question->whatsapp_no = $request->get('whatsapp_no');
        $question->monthly_donation = $request->get('monthly_donation');
        $question->admission_date = $request->get('admission_date');
        $question->blood_group = $request->get('blood_group');
        $question->previous_school = $request->get('previous_school');


        if ($request->file('proof1')) {

            $file = $request->file('proof1');
            $destinationPath = 'students_photo/';
            $profileImage1 = date('YmdHis') . "." . $file->getClientOriginalExtension();
            $file->move($destinationPath, $profileImage1);
            $question['proof1'] = $profileImage1;
        }

        if ($request->file('proof2')) {

            $file = $request->file('proof2');
            $destinationPath = 'students_photo/';
            $profileImage1 = date('YmdHis') . "." . $file->getClientOriginalExtension();
            $file->move($destinationPath, $profileImage1);
            $question['proof2'] = $profileImage1;
        }

        if ($request->file('proof3')) {

            $file = $request->file('proof3');
            $destinationPath = 'students_photo/';
            $profileImage2 = date('YmdHis') . "." . $file->getClientOriginalExtension();
            $file->move($destinationPath, $profileImage2);
            $question['proof3'] = $profileImage2;
        }

        if ($request->file('proof4')) {

            $file = $request->file('proof4');
            $destinationPath = 'students_photo/';
            $profileImage3 = date('YmdHis') . "." . $file->getClientOriginalExtension();
            $file->move($destinationPath, $profileImage3);
            $question['proof4'] = $profileImage3;
        }

        if ($request->file('proof5')) {

            $file = $request->file('proof5');
            $destinationPath = 'students_photo/';
            $profileImage4 = date('YmdHis') . "." . $file->getClientOriginalExtension();
            $file->move($destinationPath, $profileImage4);
            $question['proof5'] = $profileImage4;
        }
        if ($request->file('proof6')) {

            $file = $request->file('proof6');
            $destinationPath = 'students_photo/';
            $profileImage5 = date('YmdHis') . "." . $file->getClientOriginalExtension();
            $file->move($destinationPath, $profileImage5);
            $question['proof6'] = $profileImage5;
        }



        if ($request->file('student_pic')) {

            $file = $request->file('student_pic');
            $destinationPath = 'students_photo/';
            $profileImage6 = date('YmdHis') . "." . $file->getClientOriginalExtension();
            $file->move($destinationPath, $profileImage6);
            $question['student_pic'] = $profileImage6;
        }
        $question->save();
        return redirect()->route('student.index')
            ->with('success, Question updated successfully');
    }
    public function syllabusupdate(Request $request, $id)
    {
        $question = Syllabus_type::find($id);
        $question->title = $request->get('title');
        $question->year = $request->get('year');
        $question->save();
        return redirect()->route('syllabus_types')
            ->with('success, syllabus_types updated successfully');
    }




    public function supdate(Request $request, $id)
    {
        $question = Syllabus_type::find($id);
        $question->title = $request->get('title');
        $question->save();
        return redirect()->route('syllabus_types')
            ->with('success, syllabus_types updated successfully');
    }
    public function destroy(Student $student)
    {
        $student->delete();
        return redirect()->route('student.index')
            ->with('success', 'student deleted successfull');
    }
    public function syllabus_types()
    {
        $syllabus = DB::table('syllabus_types')->get();
        return view('tsyllabus.index', compact('syllabus'));
    }
    public function add_tsyllabus(Request $request)
    {
        $data = array("title" => $request['title'], "year" => $request['year'], "created_at" => Carbon::now(), "updated_at" => now());
        DB::table('syllabus_types')->insert($data);
        return redirect()->route('syllabus_types')
            ->with('success', 'syllabus successfull');
    }
    public function deletetsyllabus($id)
    {
        $syllabus = Syllabus_type::find($id);
        $syllabus->delete();
        return redirect()->route('syllabus_types')
            ->with('success', 'syllabus deleted successfull');
    }
    public function deleteteacher($id)
    {
        $data =DB::table("teachers")
        ->where('id','=',$id)
   
        ->delete();

        return redirect()->route('groupteacher')
            ->with('success', 'teacher deleted successfull');
    }
    public function editsyllabus(Request $request, $id)
    {
        $pannel = DB::table('syllabus_types')
            ->where('syllabus_types.id', '=', $id)
            ->get();
        foreach ($pannel as $syllabus) {
            return view('tsyllabus.edit', compact('syllabus'));
        }
    }
    public function editmonth(Request $request, $id)
    {
        $pannel = DB::table('months')
            ->where('months.id', '=', $id)
            ->get();
        foreach ($pannel as $month) {
            return view('month.edit', compact('month'));
        }
    }
    public function groupteacher()
    {
        $student = DB::table("students")->get();
        $teacher = DB::table("users")->get();

        $groupteacher = DB::table('teachers')
            ->join('students', 'students.id', '=', 'teachers.student_id')
            ->join('users', 'users.id', '=', 'teachers.teacher_id')
            ->select('users.full_name','students.name','teachers.id','teachers.created_at')
            ->get();

        return view('course.index', compact('groupteacher', 'student', 'teacher'));
    }
    public function add_teacher(Request $request)
    {
        $request->validate([
            'student_id' => 'required',
            'teacher_id' => 'required',
        ]);
        $cheack = DB::table('teachers')
            ->where('teachers.student_id', '=', $request['student_id'])
            ->get();
        if (sizeof($cheack) > 0) {
            return redirect()->route('groupteacher')->with('success', 'student already in list Added successfully.');
        } else {
            $day1 = $request['student_id'];
            $teacher_id = $request['teacher_id'];
            foreach ($day1 as $save_exam) {
                $question = new Teacher;
                $question->student_id = $save_exam;
                $question->teacher_id = $teacher_id;
                $question->save();
            }
            return redirect()->route('groupteacher')->with('success', 'Teacher Added successfully.');
        }
    }
    public function  courseupdate(Request $request, $id)
    {
        $question = Course::find($id);
        $question->title = $request->get('title');
        $question->save();
        return redirect()->route('course')
            ->with('success, Course updated successfully');
    }

    public function precorrect(Request $request, $id)
    {
        $pre = DB::table('pre_ends')
            ->where('pre_ends.id', '=', $id)
            ->first();
        $add_stur = new Structure();
        $add_stur->para_id = $pre->target;
        $add_stur->teacher_id = $pre->teacher_id;
        $add_stur->student_id = $pre->student_id;
        $add_stur->arabic_date = $pre->date;
        $add_stur->course_id = $pre->course_id;
        $add_stur->save();
        $num = Carbon::createFromFormat('Y-m-d H:i:s', $pre->created_at)->format('m');
        $num = ltrim($num, '0');
        $assign = DB::table("syllabus_adds")
            ->where("syllabus_adds.student_id", "=", $pre->student_id)
            ->where("syllabus_adds.month", "=", $num)
            ->where('no_of_parah', 'like', '%Parah%')
            ->where('syllabus_adds.course_id', "=", $pre->course_id)
            ->first();
        if (empty($assign)) {
            return redirect()->route('getendpara')
                ->with('success', 'Your status not updated target course or student is invalid.');
        } else {
            $question = Pre_end::find($pre->id);
            $question->status = 1;
            $question->save();
            if (empty($assign->c_target)) {
                $data = "";
            } else {
                $data = $assign->c_target . ",";
            }
            $add = DB::table("syllabus_adds")
                ->where('id', $assign->id)
                ->update([
                    'c_target' => $data . "" . $pre->target
                ]);
        }
        return redirect()->route('getendpara')
            ->with('success', 'Your status updated .');
    }
    public function precancel(Request $request, $id)
    {
        $pre = DB::table('pre_ends')
            ->where('pre_ends.id', '=', $id)
            ->first();
        if (!empty($request->get('remark'))) {
            DB::table('pre_ends')
                ->where('id', $pre->id)
                ->update([
                    'status' => 2,
                    'remark' => $request->get('remark')
                ]);
        } elseif (empty($request->get('remark'))) {
            DB::table('pre_ends')
                ->where('id', $pre->id)
                ->update([
                    'status' => 2
                ]);
        } else {
            return redirect()->route('getendpara')
                ->with('success', 'Your status updated.');
        }
        return redirect()->route('getendpara')
            ->with('success', 'Your status updated .');
    }
    public function add_syllabi(Request $request)
    {
        $select = $request->select;
        $para[] = $request->para_id1;
        $para[] = $request->para_id2;
        $para[] = $request->para_id3;
        $para[] = $request->para_id4;
        $para[] = $request->para_id5;
        $para[] = $request->para_id6;
        $para[] = $request->para_id7;
        $para[] = $request->para_id8;
        $para[] = $request->para_id9;
        $para[] = $request->para_id10;
        $para[] = $request->para_id11;
        $para[] = $request->para_id12;
        $target = $request->para_number;
        $student = $request->student_id;
        $month = $request->month;
        $course_id  = $request->course_id;
        $year  = $request->year;
        for ($i = 0; $i < 12; $i++) {
            $question = new Syllabus_add;
            $question->year = $year;
            $question->student_id = $student;
            $question->month =  $month[$i];
            $question->course_id = $course_id;
            $question->no_of_parah = $select[$i] . $target[$i];
            $question->target = implode(',',  $para[$i]);
            $question->save();
        }
        return redirect('setsyllabus');
    }



    public function studentview(Request $request, $id)
    {

        $student =  DB::table('students')

            ->where('students.id', '=', $id)
            ->join('syllabus_types', 'syllabus_types.id', 'students.course_id')
            ->select('students.*', 'syllabus_types.title as course')
            ->first();

        return view('student.view', compact('student'));
    }

    public function studentdetail(Request $request, $id)
    {

        $student =  DB::table('students')

            ->where('students.id', '=', $id)
            ->join('syllabus_types', 'syllabus_types.id', 'students.course_id')
            ->select('students.*', 'syllabus_types.title as course')
            ->first();

        return view('student.detail', compact('student'));
    }



    public function studentsyllabus(Request $request, $id)
    {

        $syllabi = DB::table('syllabus_adds')
            ->join('syllabus_types', 'syllabus_types.id', 'syllabus_adds.course_id')
            ->where('syllabus_adds.student_id', '=', $id)
            ->select('syllabus_adds.*', 'syllabus_types.title as course')
            ->get()
            ->groupBy('course');

        return view('student.assign', compact('syllabi'));
    }


    public function studentatt(Request $request, $id)
    {

        $student = DB::table("students")
            ->where('id', '=', $id)
            ->first();

        $attendance = Attendance::where('student_id', $id)->orderBy('created_at')->get()
            ->groupBy(function ($item) {
                return $item->created_at->format('Y-m-d');
            });

        return view('student.attendance', compact('attendance', 'student'));
        
    }



    public function studentgetdetail(Request $request, $id)
    {
        $detail = DB::table('syllabus_adds')
            ->join('students', 'students.id', '=', 'syllabus_adds.student_id')
            ->join('syllabus_types', 'syllabus_types.id', '=', 'syllabus_adds.course_id')
            ->join('months', 'months.id', '=', 'syllabus_adds.month')
            ->where('syllabus_types.title', '=', $id)
            ->get();

        return view('assign.detail', compact('detail'));
    }
    public function studentupdates(Request $request, $id)
    {

        $daily_naz = DB::table('daily_naz_updates')
            ->join('students', 'students.id', '=', 'daily_naz_updates.student_id')
            ->where('students.id', '=', $id)
            ->select('students.name', 'daily_naz_updates.*')
            ->get()
            ->groupBy('name');
        $month_naz = DB::table('daily_naz_updates')->get()
            ->groupBy('month');

        /////hifz

        $daily_hifz = DB::table('hifz_updates')
            ->join('students', 'students.id', '=', 'hifz_updates.student_id')
            ->select('students.name', 'hifz_updates.*')
            ->where('students.id', '=', $id)
            ->get()
            ->groupBy('name');
        $month_hifz = DB::table('hifz_updates')->get()->groupBy('month');

        ////dor
        $daily_dor = DB::table('dor_updates')
            ->join('students', 'students.id', '=', 'dor_updates.student_id')
            ->select('students.name', 'dor_updates.*')
            ->where('students.id', '=', $id)
            ->get()
            ->groupBy('name');
        $month_dor = DB::table('dor_updates')->get()
            ->groupBy('month');

        return view('student.update', compact('daily_naz', 'month_naz', 'daily_hifz', 'month_hifz', 'daily_dor', 'month_dor'));
    }

    public function promote(Request $request){
        // return $request;

if($request->get('demo')==1){
        $result = DB::table('students')
        ->where('name',$request->get('student'))
        ->where('course_id',$request->get('course1'))
        ->update([
            'course_id' => $request->get('course2')
        ]);
        
    }else{
        $result = DB::table('students')
        ->where('course_id',$request->get('course1'))
        ->update([
            'course_id' => $request->get('course2')
        ]);
        
    }
        if($result){
            return redirect()->back();
        }else{
            return redirect()->back();
        }
    


    }

public function getstud(Request $request){

    // return $request;

    $date = DB::table('students')
    ->where('name',$request['student_id'])
    ->join('syllabus_types','syllabus_types.id','=','students.course_id')
    ->pluck("syllabus_types.title","syllabus_types.id");

return response()->json($date);

}


}
