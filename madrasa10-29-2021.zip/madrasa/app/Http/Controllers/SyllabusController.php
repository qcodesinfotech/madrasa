<?php

namespace App\Http\Controllers;

use App\Models\syllabus;
use App\Models\Course;
use App\Models\Syllabus_type;
use App\Models\month;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SyllabusController extends Controller
{
    public function index()
    {

        $syllabus_types = DB::table('syllabus_types')->pluck("title", "id");

        $syllabus = DB::table('syllabus_types')->get();

        $syllabi = DB::table('syllabi')
        ->join('syllabus_types', 'syllabus_types.id', '=', 'syllabi.syllabus_id')

        ->select('syllabi.*', 'syllabus_types.title as syllabus_type')
        ->get();
        return view('syllabus.index', compact( 'syllabus', 'syllabi'));
    }

    public function edit(Request $request,$id)
    {
        $syllabi = DB::table('syllabi')
        ->where('syllabi.id','=',$id)
        ->join('syllabus_types', 'syllabus_types.id', '=', 'syllabi.syllabus_id')

        ->select('syllabi.*', 'syllabus_types.title as syllabus_type')
        ->get();
        $syllabus = DB::table('syllabus_types')->get();

        foreach($syllabi as $syllabi){
         return view('syllabus.edit', compact('syllabi','syllabus',));
        }
    }
    public function update(Request $request,$id)
    {
        $question = Syllabus::find($id);
        $question->syllabus_id = $request->get('syllabus_id');
        $question->total = $request->get('total');
        $question->target1 = $request->get('target1');
        $question->target2 = $request->get('target2');
        $question->target3 = $request->get('target3');
        $question->target4 = $request->get('target4');
        $question->target5 = $request->get('target5');
        $question->target6 = $request->get('target6');
        $question->save();
        return redirect()->route('syllabus.index')
       ->with('success, syllabus updated successfully');
    }

    public function store(Request $request)
    {

        $request->validate([
            'syllabus_id' => 'required',
            'total' => 'required',
            'target1' => 'required',
            'target2' => 'required',
            'target3' => 'required',
            'target4' => 'required',
            'target5' => 'required',
            'target6' => 'required'
        ]);
        
        syllabus::create($request->all());
        return redirect()->route('syllabus.index')
            ->with('success', 'syllabus created successfully.');
    }




    public function destroy(syllabus $syllabus, $id)
    {
        $syllabus = syllabus::find($id);
        $syllabus->delete();
        return redirect()->route('syllabus.index')->with('success', 'syllabus deleted successfully');

    }


    public function getmonth()
    {
        $month = DB::table('months')->get();
        return view('month.index', compact('month'));
    }


    public function addmonth(Request $request)
    {
        $request->validate([
            'month' => 'required',
        ]);
        month::create($request->all());
        return redirect()->route('getmonth')->with('success', 'date Added successfully.');
    }

    public function deletetmonth($id)
    {

        $syllabus = month::find($id);
        $syllabus->delete();
        return redirect()->route('getmonth')
            ->with('success', 'month deleted successfully');
    }


    public function  monthupdate(Request $request,$id)
    {


        $question = month::find($id);
        $question->month= $request->get('title');
        $question->save();
          return redirect()->route('getmonth')
        ->with('success, Month updated successfully');
    }


}
