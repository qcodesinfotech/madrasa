

<style>
    .adj {
        padding: 10px;
    }
</style>
<div class="adj">
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="text-center font-weight-bolder">
                <h4 class="font-weight-bold">Edit Course</h4>
            </div>
            
    </div>
</div>
<?php if($errors->any()): ?>
<div class="alert alert-danger">
    <strong>Whoops!</strong> There were some problems with your input.<br><br>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>

<?php endif; ?>
<form action="<?php echo e(route('sparaupdate', $para->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Para ORder:</strong>
                <input type="text" name="para_order" value="<?php echo e($para->para_order); ?>" class="form-control" placeholder="Name">
            </div>
            <div class="form-group">
                <strong>student Id:</strong>
                <input type="text" name="student_id" value="<?php echo e($para->student_id); ?>" class="form-control" placeholder="Name">
            </div>
            <div class="form-group">
                <strong>Para Id:</strong>
                <input type="text" name="para_id" value="<?php echo e($para->para_id); ?>" class="form-control" placeholder="Name">
            </div>
          
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <button type="submit" class="btn btn-primary">Submit</button>
            <a href="<?php echo e(route('student_based')); ?>" class="btn btn-danger">close</a>
        </div>
    </div>

</form>
</div>
<?php /**PATH C:\xampp\htdocs\laravel\Madrasa\resources\views/student_parah/edit.blade.php ENDPATH**/ ?>