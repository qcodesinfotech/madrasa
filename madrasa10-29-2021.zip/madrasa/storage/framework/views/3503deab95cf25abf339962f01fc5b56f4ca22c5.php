
<?php $__env->startSection('content'); ?>

<div style="border: 2px solid gray; border-radius:5px; font-size:15px; text-align:center;">
       
        <?php $i = 1;
        $no_q = $category->no_of_questions +1;
       
        echo "<h4>" . "No Of Question=> " . sizeof($question) . "</h4>";
        ?>
      </div>
      <!-- /////////////////////////////////////////////////// -->

    </div>
    <!--//table-responsive-->
  </div>
  <!--//app-card-body-->
  </div>
  <!--//app-card-->
  </div>
  <style>
    .table {
      margin-left: 20%;
    }

    @media  only screen and (max-width:1200px) {
      .table {
        margin-left: 0%;
      }
    }
  </style>
  <div class="tab-content" id="orders-table-tab-content" style="margin:2%;">
    <div class="tab-pane fade show active" id="orders-all" role="tabpanel" aria-labelledby="orders-all-tab">
      <div class="app-card app-card-orders-table shadow-sm mb-5">
        <div class="app-card-body">
          <div class="table-responsive">

            <?php if($message = Session::get('success')): ?>

            <div class="alert alert-success">
              <p><?php echo e($message); ?></p>
            </div>
            <?php endif; ?>


            <table class="table app-table-hover mb-0 text-left">
              <thead>
                <tr>
                  <th class="cell">S NO</th>
                  <th class="cell">Questions</th>
                </tr>
              </thead>
              <tbody>

                <form action="<?php echo e(route('examquestion')); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('POST'); ?>
                  <?php $__currentLoopData = $question; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                  <tr>
                  <?php if($i==$no_q): ?> <?php break; ?>; <?php endif; ?>
                    <td class="cell"><?php echo e($i++); ?></td>
                    <td class="cell"><input type="hidden" name="day[]" value="<?php echo e($data->id); ?>"><?php echo e($data->title); ?></td>
                    </tr>    
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td>Date</td>
                    <?php 
$datetime = new DateTime('tomorrow');
$date= $datetime->format('Y-m-d');
?>
                    <th class="cell"><input style="font-size:10px;" name="date" value="<?php echo e($date); ?>" type="date" disabled></th>
                  </tr>
              </tbody>
            </table>
            <button type="submit" style="margin-left:50%;" name="submit" class="btn btn-success">submit</button>
  </from>





       
          </div>

        </div>
        <!--//app-card-body-->
      </div>
      <!--//app-card-->
    </div>
  </div>
  </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Student-App\resources\views/question/getquestion.blade.php ENDPATH**/ ?>