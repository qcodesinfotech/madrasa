
<?php $__env->startSection('content'); ?>
<div class="app-wrapper">
	<div class="app-content pt-3 p-md-3 p-lg-4">
		<div class="container-xl">
			<div class="row g-3 mb-4 align-items-center justify-content-between">
				<div class="col-auto">
					<h1 class="app-page-title mb-0">Naz Update</h1>
				</div>
				<div class="col-auto">
					<div class="page-utilities">
						<div class="row g-2 justify-content-start justify-content-md-end align-items-center">
							<div class="col-auto">
								<style>
									input {
										text-transform: capitalize;
									}
									.cell{
										text-align:center;
									}
                                    th,td{
                                        text-transform: capitalize;
                                    }
								</style>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="tab-content" id="orders-table-tab-content">
				<div class="tab-pane fade show active" id="orders-all" role="tabpanel" aria-labelledby="orders-all-tab">
					<div class="app-card app-card-orders-table shadow-sm mb-5">
						<div class="app-card-body">
							<div class="table-responsive">
								<?php if($message = Session::get('success')): ?>
								<div class="alert alert-success">
									<p><?php echo e($message); ?></p>
								</div>

								<?php endif; ?>
								<table class="table app-table-hover mb-0 text-left">

									<thead style="background-color:rgba(128, 128, 128, 0.323);">

										<tr>
											<th class="cell">Id</th>
											<th class="cell">Arabic Date</th>
											<th class="cell">Day</th>
											<th class="cell">Old Exam</th>
											<th class="cell">Exam 1</th>
											<th class="cell">Exam 2</th>
											<th class="cell">Exam 3</th>
											<th class="cell">Total</th>
											<th class="cell">Revision</th>
											<th class="cell">NO Exams</th>
											<th class="cell">Total sub Weeks</th>
											<th class="cell">ruku</th>
											<th class="cell">Nisf</th>
											<th class="cell">Overall para</th>
											<th class="cell">Teacher</th>
											<th class="cell">Student</th>
											<th class="cell">Action</th>
										</tr>
									</thead>
									<tbody>
										<?php $i=1; ?>
										<?php $__currentLoopData = $daily_naz; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

										<tr>
											<td class="cell"><?php echo e($i++); ?></td>
											<td class="cell"><?php echo e($data->arabic_date); ?></td>
											<td class="cell"><?php echo e($data->day); ?></td>
											<td class="cell"><?php echo e($data->old_exam); ?></td>
											<td class="cell"><?php echo e($data->exam_1); ?></td>
											<td class="cell"><?php echo e($data->exam_2); ?></td>
											<td class="cell"><?php echo e($data->exam_3); ?></td>
											<td class="cell"><?php echo e($data->total); ?></td>
											<td class="cell"><?php echo e($data->revision); ?></td>
											<td class="cell"><?php echo e($data->n_exam); ?></td>
											<td class="cell"><?php echo e($data->total_sub_week); ?></td>
											<td class="cell"><?php echo e($data->ruku); ?></td>
											<td class="cell"><?php echo e($data->nisf); ?></td>
											<td class="cell"><?php echo e($data->overall_para); ?></td>
											<td class="cell"><?php echo e($data->teacher_id); ?></td>
											<td class="cell"><?php echo e($data->student_id); ?></td>


                                            <td class="cell" style="display: flex;">
												<a href="<?php echo e(route('nazedit',$data->id)); ?>"  class="btn btn-primary" ><i class="fas fa-edit fa-1x"></i></a>
											
												<form action="<?php echo e(route('nazdelete',$data->id)); ?>" method="POST" style="display: inline">
													<?php echo csrf_field(); ?>
													<?php echo method_field('DELETE'); ?>
												<button type="submit" onclick="return confirm(' you want to delete?');" class="btn btn-danger"><i class="fas fa-trash fa-1x"></i></button></td>
												</form>
										</tr>
                                    </tr>
								<?php
if($data->day=="friday"){
    ?>
    <tr>
            <td colspan="5"> one  </td>
                <td  colspan="3">  two </td>
                <td  colspan="3">  three </td>
                <td  colspan="3"> four  </td>
            </tr>
   
    
  
        <?php
}


?>
								
                                      
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</tbody>
								</table>

							</div>
							<!--//table-responsive-->

						</div>
						<!--//app-card-body-->
					</div>
					<!--//app-card-->
				</div>
				<!--//tab-pane-->
			
				<div class="modal fade" id="mediumModal" tabindex="-1" role="dialog" aria-labelledby="mediumModalLabel" aria-hidden="true">
					<div class="modal-dialog" role="document">
						<div class="modal-content">
							<div class="modal-header">
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
							<div class="modal-body" id="mediumBody">
								<div>

								</div>
							</div>
						</div>
					</div>
				</div>


				<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
				<!-- Script -->
				<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
				<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js' type='text/javascript'></script>

				<!-- Font Awesome JS -->
				<script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous">
				</script>
				<script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous">
				</script>
				<script>
					// display a modal (medium modal)
					$(document).on('click', '#mediumButton', function(event) {
						event.preventDefault();
						let href = $(this).attr('data-attr');
						$.ajax({
							url: href,
							beforeSend: function() {
								$('#loader').show();
							},
							// return the result
							success: function(result) {
								$('#mediumModal').modal("show");
								$('#mediumBody').html(result).show();
							},
							complete: function() {
								$('#loader').hide();
							},
							error: function(jqXHR, testStatus, error) {
								console.log(error);
								alert("Page " + href + " cannot open. Error:" + error);
								$('#loader').hide();
							},
							timeout: 8000
						})
					});
				</script>
				<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell\Downloads\madrasa\Madrasa\resources\views/paras/naz.blade.php ENDPATH**/ ?>