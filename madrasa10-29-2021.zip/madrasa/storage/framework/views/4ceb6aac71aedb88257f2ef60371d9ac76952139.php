
<?php $__env->startSection('content'); ?>


    <?php use App\Http\Controllers\ParaController; ?>

    <div class="app-wrapper">
        <div class="app-content pt-3 p-md-3 p-lg-4">
            <div class="container-xl">
                <div class="row g-3 mb-4 align-items-center justify-content-between">
                    <div class="col-auto">
                        <h1 class="app-page-title mb-0">DOR Update</h1>
                    </div>
                    <div class="col-auto">
                        <div class="page-utilities">
                            <div class="row g-2 justify-content-start justify-content-md-end align-items-center">
                                <div class="col-auto">
                             
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="hello">
                    <form action="<?php echo e(route('checkdor')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('post'); ?>
                        <div>
                            <select class="form-select" name="month_id" id="" style="width:50%;">
                                <?php $__currentLoopData = $month; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data => $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $dt = DateTime::createFromFormat('!m', $data); ?>
                                    <option value="<?php echo e($data); ?>"><?php echo e($dt->format('F')); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <p></p>


                            <select class="form-select" name="student_id" id="" style="width:50%;">
                                <?php $__currentLoopData = $daily_naz; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data => $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($data); ?>"><?php echo e($data); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                        </div>
                        <p></p>
                        <div style="margin-left:40%; ">
                            <input type="number" name="year" class="form-control" placeholder="Eg 2021" required>
                        </div>
                </div>

                <button style="margin:4px 42%;" type="submit" class="btn btn-secondary">Submit</button>
            </form>
            <div class="tab-content" id="orders-table-tab-content">
                <div class="tab-pane fade show active" id="orders-all" role="tabpanel" aria-labelledby="orders-all-tab">
                    <div class="app-card app-card-orders-table shadow-sm mb-5">
                        <div class="app-card-body">
                            <div class="table-responsive">
                                <?php if($message = Session::get('success')): ?>
                                    <div class="alert alert-success">
                                        <p><?php echo e($message); ?></p>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <?php if(isset($array)){  ?>
                            <?php $__currentLoopData = $array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                $startday = $value['startday'];
                                $month = $value['month'];
                                $startday = $value['startday'];
                                $date = $value['date'];
                                $year = $value['year'];
                                $totalday = $value['totalday'];
                                $endday = $value['end-day'];
                                $enddate = $value['end-date'];
                                $startdate = $value['start-date'];
                                ?>
                           
                            <footer id="print">
                                <?php $dt = DateTime::createFromFormat('!m', $value['month']); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <h2> <?php echo e($dt->format('F')); ?></h2>
                                <style>
                                    input {
                                        text-transform: capitalize;
                                    }

                                    .cell,
                                    td,
                                    th {
                                        text-align: center;
                                        text-transform: capitalize;
                                       font-weight:500 !important;
                                        color: black !important;
                                        font-weight: bolder;
                                        border: 2px solid black !important;
                                    }

                                    h2 {
                                        text-align: center;
                                        text-transform: uppercase;
                                        border-top: 2px solid red;
                                        border-bottom: 2px solid blue;
                                    }

                                    .hello div {
                                        display: flex;
                                    }


                      

                                </style>
                            <table class="table app-table-hover mb-0 text-left">
                                <thead>
                                    <tr style="background-color:rgba(51, 51, 51, 0.583); ">
                                        <th class="cell">Total</th>
                                        <th class="cell">Exam3</th>
                                        <th class="cell">Exam2</th>
                                        <th class="cell">Exam1</th>
                                        <th class="cell">Revision</th>
                                        <th class="cell">OldExam</th>
                                        <th class="cell">Day</th>
                                        <th class="cell">Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                      for($i=-1;$i<=7;$i++){
                                        if($i==$startday){ 
                                        break; }else{ ?>
                                    <tr >
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td>---</td>
                                        <td>0000-00-00</td>
                                    </tr>
                                    <?php }}; ?>
                                    <?php $postion = 0; ?>
                                    <?php $__currentLoopData = $period; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($date=="Friday"){ ?><tr>
                                            <td>Week</td>
                                        </tr><?php } ?>
                                        <?php
                                        $allowed = false;
                                        $daymonth = date('d', strtotime($value['date'])); ?>
                                        <?php for($i = 0; $i < sizeof($array); $i++): ?>
                                        <?php  if($daymonth==$array[$i]['date']){  ?>
                                            <tr >
                                                <td><?php echo e($array[$i]['total']); ?></td>
                                            <td><?php echo e($array[$i]['exam_1']); ?>

                                           
                                            <br>
                                                <?php echo e($array[$i]['exam_1a']); ?>

                                            </td>
                                            <td>
                                                <?php echo e($array[$i]['exam_2']); ?>

                                                 <br>
                                                     <?php echo e($array[$i]['exam_2a']); ?>

                                            </td>
                                            <td>
                                                <?php echo e($array[$i]['exam_3']); ?>

                                                 <br>
                                                     <?php echo e($array[$i]['exam_3a']); ?>

                                            </td>
                                            <td><?php echo e($array[$i]['revision']); ?></td>
                                            <td></td><td><?php echo e($date = date('l', strtotime($value['date']))); ?></td>
                                                <td><?php echo e($value['date']); ?></td>          
                                            </tr>
                                <?php
                                        $allowed = true;
                                        } ?>
                                        <?php endfor; ?>
                                        <?php if(!$allowed){ ?>
                                        <tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td><?php echo e($date = date('l', strtotime($value['date']))); ?></td>
                                            <td><?php echo e($value['date']); ?></td>
                                        </tr>
                                        <?php } ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                            </footer>
                        </div>
                        <!--//app-card-body-->
                    </div>
                    <!--//app-card-->
                    <input type="button" onclick="printDiv('print')" value="print dor!" />
                </div>
                <?php } ?>

              <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
              <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
              <script>
              function printDiv(print) {
                var printContents = document.getElementById(print).innerHTML;
                var originalContents = document.body.innerHTML;
           
                document.body.innerHTML = printContents;
           
                window.print();
           
                document.body.innerHTML = originalContents;
           } 
           </script>
            <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\madrasa\resources\views/paras/dor.blade.php ENDPATH**/ ?>