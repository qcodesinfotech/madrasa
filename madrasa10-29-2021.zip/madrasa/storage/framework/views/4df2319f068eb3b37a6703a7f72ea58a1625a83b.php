

<?php $__env->startSection('content'); ?>

<style>
	.form {
		margin-left: 30%;
		width: 50%;
		background-color: lightgray;
		padding: 5px 20px;
		border-radius: 6px;
	}

	label {
		text-align: center;
	}
</style>

<div class="form">
	<?php if($errors->any()): ?>
	<div class="alert alert-danger">
		<strong>Whoops!</strong> There were some problems with your input.<br><br>
		<ul>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li><?php echo e($error); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>
	<?php endif; ?>

<form action="<?php echo e(route('nazupdate',$daily_naz->id)); ?>" method="POST" enctype="multipart/form-data">
		<?php echo csrf_field(); ?>
		<?php echo method_field('PUT'); ?>
		<label class="form-label" for="customFile">Arabic Date</label>
		<input type="text" name="arabic_date" value="<?php echo e($daily_naz->arabic_date); ?>" class="form-control" id="customFile" />
		
		<label class="form-label" for="customFile">Day</label>
		<input type="text" name="day" value="<?php echo e($daily_naz->day); ?>" class="form-control" id="customFile" />
		
		<label class="form-label" for="customFile">Old Exam</label>
		<input type="text" name="old_exam" value="<?php echo e($daily_naz->old_exam); ?>" class="form-control" id="customFile" />
		
		<label class="form-label" for="customFile">Exam 1</label>
		<input type="text" name="exam_1" value="<?php echo e($daily_naz->exam_1); ?>" class="form-control" id="customFile" />
		
		<label class="form-label" for="customFile">Exam 2</label>
		<input type="text" name="exam_2" value="<?php echo e($daily_naz->exam_2); ?>" class="form-control" id="customFile" />
		
		<label class="form-label" for="customFile">Exam 3</label>
		<input type="text" name="exam_3" value="<?php echo e($daily_naz->exam_3); ?>" class="form-control" id="customFile" />
		
		<label class="form-label" for="customFile">Total</label>
		<input type="text" name="total" value="<?php echo e($daily_naz->total); ?>" class="form-control" id="customFile" />
		
		<label class="form-label" for="customFile">Revision</label>
		<input type="text" name="revision" value="<?php echo e($daily_naz->revision); ?>" class="form-control" id="customFile" />
		
		<label class="form-label" for="customFile">N Exam</label>
		<input type="text" name="n_exam" value="<?php echo e($daily_naz->n_exam); ?>" class="form-control" id="customFile" />
		
		<label class="form-label" for="customFile">Total sub Week</label>
		<input type="text" name="total_sub_week" value="<?php echo e($daily_naz->total_sub_week); ?>" class="form-control" id="customFile" />
		
		<label class="form-label" for="customFile">Ruku</label>
		<input type="text" name="ruku" value="<?php echo e($daily_naz->ruku); ?>" class="form-control" id="customFile" />
		
		<label class="form-label" for="customFile">Nisf</label>
		<input type="text" name="nisf" value="<?php echo e($daily_naz->nisf); ?>" class="form-control" id="customFile" />
		
		<label class="form-label" for="customFile">Overall Para</label>
		<input type="text" name="overall_para" value="<?php echo e($daily_naz->overall_para); ?>" class="form-control" id="customFile" />
		
		<label class="form-label" for="customFile">Teacher</label>
		<select name="teacher_id" class="form-select" id="" required>
			<option value="<?php echo e($daily_naz->teacher_id); ?>"><?php echo e($daily_naz->teacher); ?></option>
		<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<option value="<?php echo e($data->id); ?>"><?php echo e($data->full_name); ?></option>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
		</select>		
	
		<label class="form-label" for="customFile">student</label>
		<select name="student_id" class="form-select" id="" required>
			<option value="<?php echo e($daily_naz->student_id); ?>"><?php echo e($daily_naz->name); ?></option>
			<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<option value="<?php echo e($data->id); ?>"><?php echo e($data->name); ?></option>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</select>

		<button style="margin-left:34%;" type="submit" class="btn btn-primary">Submit</button>
	</form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\madrasa\resources\views/paras/editnaz.blade.php ENDPATH**/ ?>