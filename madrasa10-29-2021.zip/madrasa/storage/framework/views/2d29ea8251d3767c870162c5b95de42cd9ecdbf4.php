
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="text-center">
            <h2 class="font-weight-bold">Question</h2>
        </div>
    </div>

    <div class="row mx-auto">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Question:</strong>
                <?php echo e($question->title); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Option 1:</strong>
                <?php echo e($question->option_1); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>option 2:</strong>
                <?php echo e($question->option_2); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Option 3:</strong>
                <?php echo e($question->option_3); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>option 1:</strong>
                <?php echo e($question->option_4); ?>

            </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Question image:</strong>
                <img src="questions/<?php echo e($question->question_image); ?>" width="40px" alt="">

            </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>option 1:</strong>
                <img src="questions/<?php echo e($question->option_image_1); ?>" width="40px" alt="">

            </div>
        </div>


        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>option 2:</strong>
                <img src="questions/<?php echo e($question->option_image_2); ?>" width="40px" alt="">

            </div>
        </div>


        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>option 3:</strong>
                <img src="questions/<?php echo e($question->option_image_3); ?>" width="40px" alt="">

            </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>option 4:</strong>
                <img src="questions/<?php echo e($question->option_image_4); ?>" width="40px" alt="">

            </div>
        </div>
        
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Date Created:</strong>
                <?php echo e(date_format($question->created_at, 'jS M Y')); ?>

            </div>
        </div>
    </div>
    <?php /**PATH C:\xampp\htdocs\laravel\Student-App\resources\views/question/show.blade.php ENDPATH**/ ?>