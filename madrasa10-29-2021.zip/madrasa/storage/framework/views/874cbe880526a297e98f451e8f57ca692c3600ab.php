<?php $__env->startSection('content'); ?>
<style>
    .form {
        margin-top: 5%;
        margin-left: 30%;
        width: 50%;
        background-color: lightgray;
        padding: 5px 20px;
        border-radius: 6px;
    }

    label {
        text-align: center;
    }
</style>

<div class="form">
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
    <form action="<?php echo e(route('category.update', $category->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <h2 style="text-align:center;">Edit class Data</h2>
        </div>

        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Title</label>
        <input type="text" name="title" class="form-control" value="<?php echo e($category->title); ?>">     
        <input type="hidden" name="is_deleted" class="form-control" value="<?php echo e($category->is_deleted); ?>">
        </div>


        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">From</label>
        <input type="text" name="from" class="form-control" value="<?php echo e($category->from); ?>">     
   
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">To</label>
        <input type="text" name="to" class="form-control" value="<?php echo e($category->to); ?>">     
      
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">No Of Question</label>
        <input type="text" name="no_of_questions" class="form-control" value="<?php echo e($category->no_of_questions); ?>">     
     
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Time Limit</label>
        <input type="text" name="time_limit" class="form-control" value="<?php echo e($category->no_of_questions); ?>">     
     
        </div>


        <div class="mb-3">
            <label for="recipient-name" class="col-form-label">Section</label>
            <select name="subject_id" class="form-select" id="">
            <option value="<?php echo e($category->id); ?>">Select Section</option>
             <?php $__currentLoopData = $subject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <option value="<?php echo e($data->id); ?>"><?php echo e($data->subject); ?></option>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

 
        <button style="margin-left:34%;" type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Student-App 27-7\Student-App\resources\views/category/edit.blade.php ENDPATH**/ ?>