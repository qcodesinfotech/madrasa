<?php $__env->startSection('content'); ?>

<style>
	.form {
		margin-left: 30%;
		width: 50%;
		background-color: lightgray;
		padding: 5px 20px;
		border-radius: 6px;
	}

	label {
		text-align: center;
	}

</style>


<div class="form">
	<?php if($errors->any()): ?>
	<div class="alert alert-danger">
		<strong>Whoops!</strong> There were some problems with your input.<br><br>
		<ul>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li><?php echo e($error); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>
	<?php endif; ?>

    <form action="<?php echo e(route('sparaupdate', $para->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
		<label class="form-label" for="customFile">Para Id</label>
		<input type="text" name="para_id" value="<?php echo e($para->para_id); ?>" class="form-control" id="customFile" />
				

		<label class="form-label" for="customFile">student</label>
		<select name="student_id" class="form-select" id="" required>
			<option value="<?php echo e($para->student_id); ?>"><?php echo e($para->student_id); ?></option>
			<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<option value="<?php echo e($data->id); ?>"><?php echo e($data->name); ?></option>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</select>


		<label class="form-label" for="customFile">Para order</label>
		<select name="para_order" class="form-select" id="" required>
			<option value="<?php echo e($para->student_id); ?>"><?php echo e($para->para_order); ?></option>
			<?php $__currentLoopData = $paras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<option value="<?php echo e($data->id); ?>"><?php echo e($data->para_name); ?></option>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</select>

	<button style="margin-left:34%;" type="submit" class="btn btn-primary">Submit</button>
     <a href="<?php echo e(route('student_based')); ?>" class="btn btn-danger">close</a>
    </div>
	</form>
</div>

<?php $__env->stopSection(); ?>
































<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\madrasa\resources\views/student_parah/edit.blade.php ENDPATH**/ ?>