
<?php $__env->startSection('content'); ?>

<head>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
</head>


<style>
    select{
        width: 100%;
        height: 30%;
        border-radius:5px; 
    }
    table {
      font-family: Arial, Helvetica, sans-serif;
      border-collapse: collapse;
      width: 100%;
    }
    table td, table th {
      border: 1px solid #ddd;
      padding: 8px;
    }


    tr:nth-child(even) {backgrou}
tr:nth-child(odd) {background: #FFF}
    /* table tr:nth-child(even){background-color: #f2f2f2;}
     */
    table tr:hover {background-color: #ddd;}
    
    table th {
      padding-top: 12px;
      padding-bottom: 12px;
      text-align: left;
      background-color: #04AA6D;
      color: white;
    }
    td:even{

    }
    </style>
<body>
  <div style="margin:0% 30%;">
    <h2>Assign Syllabus</h2>
    <div class="form-group">


    <form action="<?php echo e(route('addassign')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('POST'); ?>
      <label for="student">Student:</label>
      <select id="student" name="student" class="form-control">
        <option value="" selected disabled>Select Student</option>
        <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value=<?php echo e($stud->id); ?>> <?php echo e($stud->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>

     <!-- ////////////////////////////////// -->

      <label>Date:</label><br>
           <select name="date" id="date"  >
       </select><br>
     

     <!-- /////////////////////////////////// -->
        <label for="month">Month:</label>
        <select name="month" id="month" class="form-control">
            <option value="" selected disabled>Select Month</option>
            <?php $__currentLoopData = $month; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value=<?php echo e($stud->id); ?>> <?php echo e($stud->month); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select> 
        <label for="course">Course :</label>
        <select name="course" id="course" class="form-control">
            <option value="" selected disabled>Course</option>
            <?php $__currentLoopData = $syllabus_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value=<?php echo e($stud->id); ?>> <?php echo e($stud->title); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <label for="course">Course year:</label>
        <select name="course_year" id="course_year" class="form-control">
            <option value="" selected disabled>Course Year</option>
            <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value=<?php echo e($stud->id); ?>> <?php echo e($stud->title); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <label for="">Month</label>
    <table id="lesson">

    </table>
 
   <button style="margin:5%;" type="submit" name="submit" class="btn btn-success">Next</button>
      </form>
      <script type=text/javascript>
        $('#student').change(function() {
          var studentID = $(this).val();
          if (studentID) {
            $.ajax({
              type: "GET",
              url: "<?php echo e(url('getstudent')); ?>?student_id=" + studentID,
              success: function(res) {
                if (res) {
                  $("#date").empty();
                  $("#date").append('');
                  $.each(res, function(key, value) {
                    $("#date").append('<option value="' + key + '">' + value + '</option>'
                    
                    );
                  });
                } else {
                  $("#date").empty();
                }
              }
            });
          } else {
            $("#date").empty();
          }
 });


 
        $('#course_year').on('change', function() {
          var course =$("#course").val();
          var course_year = $("#course_year").val();      
          var date = $("#month").val();      
          if (course_year) {
            $.ajax({
              type: "GET",
              url: "<?php echo e(url('getsyllabi')); ?>?course=" + course+"&course_year="+course_year+"&date="+date,
              success: function(obj) {
                if (obj) {
                  $("#lesson").empty();
                  $("#lesson").append('<tr><th>course</th> <th>Month</th><tr>');
                  $.each(obj, function(key,value) {
                    $("#lesson").append('<tr><td>'+ value.course +'</td><td>'+ value.month +'</td></tr>');
                  
                  });
                
                } else {
                  $("#lesson").empty();
                }
              }
            });
          } else {
            $("#lesson").empty();
          }

        });

      </script>
</body>

</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Madrasa\resources\views/assign/index.blade.php ENDPATH**/ ?>