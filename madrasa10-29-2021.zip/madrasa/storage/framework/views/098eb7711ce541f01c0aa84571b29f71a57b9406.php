<?php $__env->startSection('content'); ?>

<style>
	.form {
		margin-left: 30%;
		width: 50%;
		background-color: lightgray;
		padding: 5px 20px;
		border-radius: 6px;
	}

	label {
		text-align: center;
	}
</style>

<div class="form">
	<?php if($errors->any()): ?>
	<div class="alert alert-danger">
		<strong>Whoops!</strong> There were some problems with your input.<br><br>
		<ul>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li><?php echo e($error); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>
	<?php endif; ?>
	<form action="<?php echo e(route('question.update', $question->id)); ?>" method="POST" enctype="multipart/form-data">
		<?php echo csrf_field(); ?>
		<?php echo method_field('PUT'); ?>
		<div class="mb-3">
			<h4 style="text-align:center;">Edit question Data</h4>
		</div>
		<div class="mb-3">
			<label for="recipient-name" class="col-form-label">Question Name</label>
			<input type="text" value="<?php echo e($question->title); ?>" name="title" class="form-control" id="recipient-name">
		</div>
		<div class="mb-3">
			<label for="recipient-name" class="col-form-label">Option1</label>

			<input type="text" value="<?php echo e($question->option_1); ?>" name="option_1" class="form-control" id="recipient-name">

		</div>
		<div class="mb-3">
			<label for="recipient-name" class="col-form-label">Option2</label>

			<input type="text" value="<?php echo e($question->option_2); ?>" name="option_2" class="form-control" id="recipient-name">

		</div>
		<div class="mb-3">
			<label for="recipient-name" class="col-form-label">Option3</label>
			<input type="text" value="<?php echo e($question->option_3); ?>" name="option_3" class="form-control" id="recipient-name">
		</div>
		<div class="mb-3">
			<label for="recipient-name" class="col-form-label">Option4</label>
			<input type="text" value="<?php echo e($question->option_4); ?>" name="option_4" class="form-control" id="recipient-name">
		</div>
		<div class="mb-3">
			<label for="recipient-name" class="col-form-label">Answer</label>

			<input type="text" value="<?php echo e($question->answer); ?>" name="answer" class="form-control" id="recipient-name">

		</div>

		<div class="mb-3">
			<label for="recipient-name" class="col-form-label">Board</label>
			<select name="board_id" class="form-select" id="">
				<option value="<?php echo e($question->board_id); ?>"><?php echo e($question->board); ?></option>
				<?php $__currentLoopData = $board; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<option value="<?php echo e($data->id); ?>"><?php echo e($data->title); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
		</div>
		<div class="mb-3">
			<label for="recipient-name" class="col-form-label">Question Category</label>
			<select name="category_id" class="form-select" id="">
				<option value="<?php echo e($question->category_id); ?>"><?php echo e($question->class); ?></option>
				<?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<option value="<?php echo e($data->id); ?>"><?php echo e($data->title); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
		</div>
	
		<div class="mb-3">
			<label for="recipient-name" class="col-form-label">Medium</label>
			<select name="medium_id" class="form-select" id="">
				<option value="<?php echo e($question->medium_id); ?>"><?php echo e($question->medium); ?></option>
				<?php $__currentLoopData = $medium; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<option value="<?php echo e($data->id); ?>"><?php echo e($data->title); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
		</div>
		<div class="mb-3">
			<label for="recipient-name" class="col-form-label">Subject</label>
			<select name="subject_id" class="form-select" id="">
				<option value="<?php echo e($question->subject_id); ?>"><?php echo e($question->subject); ?></option>
				<?php $__currentLoopData = $subject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<option value="<?php echo e($data->id); ?>"><?php echo e($data->subject); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
		</div>
		<div class="mb-3">
			<label for="recipient-name" class="col-form-label">Lession</label>
			<select name="lession_id" class="form-select" id="">
				<option value="<?php echo e($question->lession_id); ?>"><?php echo e($question->lession); ?></option>
				<?php $__currentLoopData = $lession; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<option value="<?php echo e($data->id); ?>"><?php echo e($data->title); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
		</div>
		<label class="form-label" for="customFile">Question Image</label>
		<input type="file" name="question_image" value="<?php echo e($question->question_image); ?>" class="form-control" id="customFile" />

		<label class="form-label" for="customFile">Option Image 1</label>
		<input type="file" name="option_image_1" value="<?php echo e($question->option_image_1); ?>" class="form-control" id="customFile" />

		<label class="form-label" for="customFile">Option Image 2</label>
		<input type="file" name="option_image_2" value="<?php echo e($question->option_image_2); ?>" class="form-control" id="customFile" />

		<label class="form-label" for="customFile">Option Image 3</label>
		<input type="file" name="option_image_3" value="<?php echo e($question->option_image_3); ?>" class="form-control" id="customFile" />

		<label class="form-label" for="customFile">Option Image 4</label>
		<input type="file" name="option_image_4" value="<?php echo e($question->option_image_4); ?>" class="form-control" id="customFile" />


		<input type="hidden" name="updated" class="form-control" value="<?php echo e($question->updated); ?>">

		<button style="margin-left:34%;" type="submit" class="btn btn-primary">Submit</button>
	</form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Student-App\resources\views/question/edit.blade.php ENDPATH**/ ?>