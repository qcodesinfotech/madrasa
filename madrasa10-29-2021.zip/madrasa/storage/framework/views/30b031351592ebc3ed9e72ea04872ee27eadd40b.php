<?php $__env->startSection('content'); ?>

<style>
	.form {
		margin-left: 30%;
		width: 50%;
		background-color: lightgray;
		padding: 5px 20px;
		border-radius: 6px;
	}

	label {
		text-align: center;
	}
</style>

<div class="form">
	<?php if($errors->any()): ?>
	<div class="alert alert-danger">
		<strong>Whoops!</strong> There were some problems with your input.<br><br>
		<ul>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li><?php echo e($error); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>
	<?php endif; ?>
	<form action="<?php echo e(route('student.update', $student->id)); ?>" method="POST" enctype="multipart/form-data">
		<?php echo csrf_field(); ?>
		<?php echo method_field('PUT'); ?>
		<div class="mb-3">
			<h4 style="text-align:center;">Edit Student Data</h4>
		</div>
		<div class="mb-3">
			<label for="recipient-name" class="col-form-label">Name</label>
			<input type="text" value="<?php echo e($student->name); ?>" name="name" class="form-control" id="recipient-name">
		</div>

		<div class="mb-3">
			<label for="recipient-name" class="col-form-label">AdmissionNumber</label>
			<input type="text" value="<?php echo e($student->admission_no); ?>" name="admission_no" class="form-control" id="recipient-name">
		</div>

		<div class="mb-3">
			<label for="recipient-name" class="col-form-label">Father Name</label>
			<input type="text" value="<?php echo e($student->father_name); ?>" name="father_name" class="form-control" id="recipient-name">

		</div>

		<div class="mb-3">
			<label for="recipient-name" class="col-form-label">Course</label>
		<select class="form-select" name="course" id="">

			<option value="<?php echo e($student->course_id); ?>"><?php echo e($student->course); ?></option>
			<?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<option value="<?php echo e($data->id); ?>"><?php echo e($data->title); ?></option>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


		</select>

		</div>

		<div class="mb-3">
			<label for="recipient-name" class="col-form-label">Father Occupation</label>
			<input type="text" value="<?php echo e($student->father_occupation); ?>" name="father_occupation" class="form-control" id="recipient-name">
		</div>

		<div class="mb-3">
			<label for="recipient-name" class="col-form-label">Date of Birth</label>
			<input type="date" value="<?php echo e($student->date_of_birth); ?>" name="date_of_birth" class="form-control" id="recipient-name">
		</div>
		<div class="mb-3">
			<label for="recipient-name" class="col-form-label">Blood Group</label>
			<input type="text" value="<?php echo e($student->blood_group); ?>" name="blood_group" class="form-control" id="recipient-name">
		</div>

		<label class="form-label" for="customFile">Aadhar No</label>
		<input type="text" name="aadhar_no" value="<?php echo e($student->aadhar_no); ?>" class="form-control" id="customFile" />

		<label class="form-label" for="customFile">Mobile No</label>
		<input type="text" name="mobile_no" value="<?php echo e($student->mobile_no); ?>" class="form-control" id="customFile" />

		<label class="form-label" for="customFile">Whatsapp No </label>
		<input type="text" name="whatsapp_no" value="<?php echo e($student->whatsapp_no); ?>" class="form-control" id="customFile" />

		<label class="form-label" for="customFile">Address</label>
		<input type="text" name="address" value="<?php echo e($student->address); ?>" class="form-control" id="customFile" />

		<label class="form-label" for="customFile">Monthly Donation</label>
		<input type="text" name="monthly_donation" value="<?php echo e($student->monthly_donation); ?>" class="form-control" id="customFile" />

        <label class="form-label" for="customFile">Admission Date</label>
		<input type="date" name="admission_date" value="<?php echo e($student->Admission_date); ?>" class="form-control" id="customFile" />

		<label class="form-label" for="customFile">Previous School</label>
		<input type="text" name="previous_school" value="<?php echo e($student->previous_school); ?>" class="form-control" id="customFile" />

    	<p></p><br>
        <label class="form-label" for="customFile">Student picture</label><br>
		<a href="<?php echo e(URL::asset('students_photo')); ?>/<?php echo e($student->student_pic); ?>">
        <img src="<?php echo e(URL::asset('students_photo')); ?>/<?php echo e($student->student_pic); ?>" width="100px"></a>
		<p></p><br>
		<input type="file" name="student_pic" value="<?php echo e($student->student_pic); ?>" class="form-control" id="customFile" />

		<label class="form-label" for="customFile">proof document image 1</label><br>
           <a href="<?php echo e(URL::asset('students_photo')); ?>/<?php echo e($student->proof1); ?>">
        <img src="<?php echo e(URL::asset('students_photo')); ?>/<?php echo e($student->proof1); ?>" width="100px"></a>
		<p></p><br>
		<input type="file" name="proof1" value="<?php echo e($student->proof1); ?>" class="form-control" id="customFile" />

		<label class="form-label" for="customFile">proof document image 2</label><br>
		<a href="<?php echo e(URL::asset('students_photo')); ?>/<?php echo e($student->proof2); ?>">
        <img src="<?php echo e(URL::asset('students_photo')); ?>/<?php echo e($student->proof2); ?>" width="100px"></a>

		<p></p><br>
		<input type="file" name="proof2" value="<?php echo e($student->proof2); ?>" class="form-control" id="customFile" />
		<label class="form-label" for="customFile">proof document image 3</label><br>
		<a href="<?php echo e(URL::asset('students_photo')); ?>/<?php echo e($student->proof3); ?>">
        <img src="<?php echo e(URL::asset('students_photo')); ?>/<?php echo e($student->proof3); ?>" width="100px"></a>

		<p></p><br>
		<input type="file" name="proof3" value="<?php echo e($student->proof3); ?>" class="form-control" id="customFile" />

		<label class="form-label" for="customFile">proof document image 4</label><br>
		<a href="<?php echo e(URL::asset('students_photo')); ?>/<?php echo e($student->proof4); ?>">
        <img src="<?php echo e(URL::asset('students_photo')); ?>/<?php echo e($student->proof4); ?>" width="100px"></a>
		<p></p><br>
		<input type="file" name="proof4" value="<?php echo e($student->proof4); ?>" class="form-control" id="customFile" />
	
        <label class="form-label" for="customFile">proof document image 5</label><br>
		<a href="<?php echo e(URL::asset('students_photo')); ?>/<?php echo e($student->proof5); ?>">
        <img src="<?php echo e(URL::asset('students_photo')); ?>/<?php echo e($student->proof5); ?>" height="100px"></a>

		<p></p><br>
		<input type="file" name="proof5" value="<?php echo e($student->proof5); ?>" class="form-control" id="customFile" />
        <label class="form-label" for="customFile">proof document image 6</label><br>
	    	<a href="<?php echo e(URL::asset('students_photo')); ?>/<?php echo e($student->proof6); ?>">
        <img src="<?php echo e(URL::asset('students_photo')); ?>/<?php echo e($student->proof6); ?>" height="100px"></a>
		<input type="file" name="proof6" value="<?php echo e($student->proof6); ?>" class="form-control" id="customFile" />
		<button style="margin-left:34%;" type="submit" class="btn btn-primary">Submit</button>
	</form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\madrasa\resources\views/student/edit.blade.php ENDPATH**/ ?>