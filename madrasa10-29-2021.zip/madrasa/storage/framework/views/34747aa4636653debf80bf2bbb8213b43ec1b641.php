<?php $__env->startSection('content'); ?>

<style>
	.form {
		margin-left: 30%;
		width: 50%;
		background-color: lightgray;
		padding: 5px 20px;
		border-radius: 6px;
	}

	label {
		text-align: center;
	}
</style>

<div class="form">
	<?php if($errors->any()): ?>
	<div class="alert alert-danger">
		<strong>Whoops!</strong> There were some problems with your input.<br><br>
		<ul>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li><?php echo e($error); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>
	<?php endif; ?>
	<form action="<?php echo e(route('syllabus.update', $syllabi->id)); ?>" method="POST" enctype="multipart/form-data">
		<?php echo csrf_field(); ?>
		<?php echo method_field('PUT'); ?>

		<div class="mb-3">
                <label for="recipient-name" class="col-form-label">Syllabus Type</label>
                <select name="syllabus_id" class="form-select" id="" required>
                    <option value="<?php echo e($syllabi->syllabus_id); ?>"><?php echo e($syllabi->syllabus_type); ?></option>
                    <?php $__currentLoopData = $syllabus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($data->id); ?>"><?php echo e($data->title); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
		</div>

		<label class="form-label" for="customFile">Target1</label>
		<input type="text" name="target1" value="<?php echo e($syllabi->target1); ?>" class="form-control" id="customFile" />
		<label class="form-label" for="customFile">Target2</label>
		<input type="text" name="target2" value="<?php echo e($syllabi->target2); ?>" class="form-control" id="customFile" />
		<label class="form-label" for="customFile">Target3</label>
		<input type="text" name="target3" value="<?php echo e($syllabi->target3); ?>" class="form-control" id="customFile" />
		<label class="form-label" for="customFile">Target4</label>
		<input type="text" name="target4" value="<?php echo e($syllabi->target4); ?>" class="form-control" id="customFile" />
		<label class="form-label" for="customFile">Target5</label>
		<input type="text" name="target5" value="<?php echo e($syllabi->target5); ?>" class="form-control" id="customFile" />
		<label class="form-label" for="customFile">Target6</label>
		<input type="text" name="target6" value="<?php echo e($syllabi->target6); ?>" class="form-control" id="customFile" />

		<label class="form-label" for="customFile">Total</label>
		<input type="text" name="total" value="<?php echo e($syllabi->total); ?>" class="form-control" id="customFile" />

<button style="margin-left:34%;" type="submit" class="btn btn-primary">Submit</button>
<a href="<?php echo e(route('syllabus.index')); ?>" class="btn btn-danger">close</a>
	</form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\madrasa\resources\views/syllabus/edit.blade.php ENDPATH**/ ?>