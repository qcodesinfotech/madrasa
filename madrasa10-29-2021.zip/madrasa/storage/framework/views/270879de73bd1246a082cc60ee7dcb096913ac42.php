<?php $__env->startSection('content'); ?>

<style>
    .form {
        margin-left: 30%;
        width: 50%;
        background-color: lightgray;
        padding: 5px 20px;
        border-radius: 6px;
    }

    label {
        text-align: center;
    }
</style>

<div class="form">
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
    <form action="<?php echo e(route('school.update', $school->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <h2 style="text-align:center;">Edit School Data</h2>
        </div>
        <div class="mb-3">
            <label for="recipient-name" class="col-form-label">Location</label>
        
            <select name="location_id" class="form-select" id="">
            <option value="<?php echo e($school->location_id); ?>"><?php echo e($school->city); ?></option>
                <?php $__currentLoopData = $location; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($data->id); ?>"><?php echo e($data->city); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="recipient-name" class="col-form-label">Board</label>
            <select name="board_id" class="form-select" id="">
            <option value="<?php echo e($school->board_id); ?>"><?php echo e($school->title); ?></option>
                <?php $__currentLoopData = $board; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($data->id); ?>"><?php echo e($data->title); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Door Number</label>
            <input type="text" name="door_number" class="form-control" value="<?php echo e($school->door_number); ?>">

        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Street</label>
            <input type="text" name="street" class="form-control" value="<?php echo e($school->street); ?>">
        </div>
        <div class="mb-3">
            <label for="exampleInputPassword1" class="form-label">School</label>
            <input type="text" name="school_name" class="form-control" value="<?php echo e($school->school_name); ?> " id="exampleInputPassword1">

        </div>
        <input type="hidden" name="updated" class="form-control" value="<?php echo e($school->updated); ?>">

        <button style="margin-left:34%;" type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Student-App\resources\views/school/edit.blade.php ENDPATH**/ ?>