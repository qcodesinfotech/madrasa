<?php $__env->startSection('content'); ?>
<style>
    .form {
        margin-top: 5%;
        margin-left: 30%;
        width: 50%;
        background-color: lightgray;
        padding: 5px 20px;
        border-radius: 6px;
    }

    label {
        text-align: center;
    }
</style>

<div class="form">
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
    <form action="<?php echo e(route('period.update', $period->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <h2 style="text-align:center;">Edit class Data</h2>
        </div>

        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Title</label>
        <input type="text" name="title" class="form-control" value="<?php echo e($period->title); ?>">     
        <input type="hidden" name="updated" class="form-control" value="<?php echo e($period->updated); ?>">
        </div>

        <div class="mb-3">
            <label for="recipient-name" class="col-form-label">Section</label>
            <select name="section_id" class="form-select" id="">
            <option value="<?php echo e($period->section_id); ?>"><?php echo e($period->section); ?></option>
             <?php $__currentLoopData = $section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <option value="<?php echo e($data->id); ?>"><?php echo e($data->title); ?></option>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        
        <div class="mb-3">
            <label for="recipient-name" class="col-form-label">Medium</label>
            <select name="medium_id" class="form-select" id="">
            <option value="<?php echo e($period->medium_id); ?>"><?php echo e($period->medium); ?></option>
            <?php $__currentLoopData = $medium; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <option value="<?php echo e($data->id); ?>"><?php echo e($data->title); ?></option>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
   
        <button style="margin-left:34%;" type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Student-App\resources\views/period/edit.blade.php ENDPATH**/ ?>