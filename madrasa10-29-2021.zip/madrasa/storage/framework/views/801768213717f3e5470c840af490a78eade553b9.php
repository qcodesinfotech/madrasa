<?php $__env->startSection('content'); ?>

<style>
    .form {
        margin-left: 30%;
        width: 50%;
        background-color: lightgray;
        padding: 5px 20px;
        margin-top: 10px;
        border-radius: 6px;
    }

    label {
        text-align: center;
    }
</style>

<div class="form">
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
    <form action="<?php echo e(route('medium.update', $medium->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <h4 style="text-align:center;">Edit Medium</h4>
        </div>
        <div class="mb-3">
        <input type="hidden" name="updated" class="form-control" value="<?php echo e($medium->updated); ?>">

            <label for="recipient-name" class="col-form-label">Medium Title</label>

                <input type="text" name="title" value="<?php echo e($medium->title); ?>" class="form-control" id="recipient-name">

        </div>
  
        <div class="mb-3">
            <label for="recipient-name" class="col-form-label">Select Board</label>
            <select name="board_id" class="form-select" id="">
                <option value="<?php echo e($medium->board_id); ?>"><?php echo e($medium->board); ?></option>
                <?php $__currentLoopData = $board; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($data->board_id); ?>"><?php echo e($data->board); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <button style="margin-left:34%;" type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Student-App\resources\views/medium/edit.blade.php ENDPATH**/ ?>