
<?php $__env->startSection('content'); ?>
<div class="app-wrapper">
	<div class="app-content pt-3 p-md-3 p-lg-4">
		<div class="container-xl">
			<div class="row g-3 mb-4 align-items-center justify-content-between">
				<div class="col-auto">
					<h1 class="app-page-title mb-0">Question</h1>
				</div>
				<div class="col-auto">
					<div class="page-utilities">
						<div class="row g-2 justify-content-start justify-content-md-end align-items-center">
							<div class="col-auto">
								<form class="table-search-form row gx-1 align-items-center">
									<div class="col-auto">
										<input type="text" id="search-orders" name="searchorders" class="form-control search-orders" placeholder="Search">
									</div>
									<div class="col-auto">
										<button type="submit" class="btn app-btn-secondary">Search</button>
									</div>
								</form>

							</div>
							<!--//col-->
							<button type="button" onMouseOver="this.style.color='#15A362'" onMouseOut="this.style.color='#676778'" style="border-radius:5px;padding:4px;background-color:white;border:1px solid #676778;;color:#676778; " class="col-auto" data-bs-toggle="modal" data-bs-target="#exampleModal" data-bs-whatever="@getbootstrap">Add question</button>
							<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
								<div class="modal-dialog">
									<div class="modal-content">
										<div class="modal-header">
											<h5 class="modal-title" id="exampleModalLabel">Add question</h5>
											<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
										</div>
										<div class="modal-body">
											<?php if($errors->any()): ?>

											<div class="alert alert-danger">

												<strong>Whoops!</strong> There were some problems with your input.<br><br>

												<ul>
													<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<li><?php echo e($error); ?></li>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</ul>
											</div>
											<?php endif; ?>
											<form action="<?php echo e(route('question.store')); ?>" method="POST" enctype="multipart/form-data">
												<?php echo csrf_field(); ?>
												<label class="form-label" for="customFile">Input CSV</label>
												<input type="file" name="file" class="form-control" id="customFile" />

												<div class="mb-3">
													<label for="recipient-name" class="col-form-label">Question Category</label>
													<select name="category_id" class="form-select" id="">
														<option value="">Add Category</option>
														<?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<option value="<?php echo e($data->id); ?>"><?php echo e($data->title); ?></option>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</select>
												</div>
												<div class="mb-3">
													<label for="recipient-name" class="col-form-label">Board</label>
													<select name="board_id" class="form-select" id="">
														<option value="">Add Board</option>
														<?php $__currentLoopData = $board; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<option value="<?php echo e($data->id); ?>"><?php echo e($data->title); ?></option>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</select>
												</div>

												<div class="mb-3">
													<label for="recipient-name" class="col-form-label">Medium</label>
													<select name="medium_id" class="form-select" id="">
														<option value="">Add medium</option>
														<?php $__currentLoopData = $medium; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<option value="<?php echo e($data->id); ?>"><?php echo e($data->title); ?></option>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</select>
												</div>
												<div class="mb-3">
													<label for="recipient-name" class="col-form-label">lesson</label>
													<select name="lesson_id" class="form-select" id="">
														<option value="">Add lesson</option>
														<?php $__currentLoopData = $lesson; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<option value="<?php echo e($data->id); ?>"><?php echo e($data->title); ?></option>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</select>
												</div>
												<div class="mb-3">
													<label for="recipient-name" class="col-form-label">Subject</label>
													<select name="subject_id" class="form-select" id="">
														<option value="">add Subject</option>
														<?php $__currentLoopData = $subject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<option value="<?php echo e($data->id); ?>"><?php echo e($data->subject); ?></option>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</select>
												</div>

										</div>
										<div class="modal-footer">
											<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
											<button type="submit" name="submit" class="btn btn-primary">Save</button>
											</form>

										</div>
									</div>
								</div>
							</div>




							<!-- Button trigger modal -->
							<button type="button" onMouseOver="this.style.color='#15A362'" onMouseOut="this.style.color='#676778'" style="border-radius:5px;padding:4px;background-color:white;border:1px solid #676778;;color:#676778; " class="col-auto" data-bs-toggle="modal" data-bs-target="#laravel">Add Input</button>

							<!-- Modal -->
							<div class="modal fade" id="laravel" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
								<div class="modal-dialog">
									<div class="modal-content">
										<div class="modal-header">
											<h5 class="modal-title" id="exampleModalLabel">Enter Question</h5>
											<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
										</div>
										<div class="modal-body">
											<?php if($errors->any()): ?>
											<div class="alert alert-danger">
												<strong>Whoops!</strong> There were some problems with your input.<br><br>
												<ul>
													<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<li><?php echo e($error); ?></li>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</ul>
											</div>
											<?php endif; ?>
											<form action="<?php echo e(route('question.save')); ?>" method="POST" enctype="multipart/form-data">
												<?php echo csrf_field(); ?>
												<?php echo method_field('POST'); ?>

												<div class="mb-3">
													<label for="recipient-name" class="col-form-label">Title</label>
													<input type="text" name="title" class="form-control" id="recipient-name">
												</div>

												<div class="mb-3">
													<label for="recipient-name" class="col-form-label">Option1</label>
													<input type="text" name="option_1" class="form-control" id="recipient-name">
												</div>
												<div class="mb-3">
													<label for="recipient-name" class="col-form-label">Option2</label>
													<input type="text" name="option_2" class="form-control" id="recipient-name">
												</div>
												<div class="mb-3">
													<label for="recipient-name" class="col-form-label">Option3</label>
													<input type="text" name="option_3" class="form-control" id="recipient-name">
												</div>
												<div class="mb-3">
													<label for="recipient-name" class="col-form-label">Option4</label>
													<input type="text" name="option_4" class="form-control" id="recipient-name">
												</div>
												<div class="mb-3">
													<label for="recipient-name" class="col-form-label">Answer</label>
													<input type="text" name="answer" class="form-control" id="recipient-name">
												</div>

												<div class="mb-3">
													<label for="recipient-name" class="col-form-label">Question Category</label>
													<select name="category_id" class="form-select" id="">
														<option value="">Add Category</option>
														<?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<option value="<?php echo e($data->id); ?>"><?php echo e($data->title); ?></option>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</select>
												</div>
												<div class="mb-3">
													<label for="recipient-name" class="col-form-label">Board</label>
													<select name="board_id" class="form-select" id="">
														<option value="">Add Board</option>
														<?php $__currentLoopData = $board; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<option value="<?php echo e($data->id); ?>"><?php echo e($data->title); ?></option>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</select>
												</div>

												<div class="mb-3">
													<label for="recipient-name" class="col-form-label">Medium</label>
													<select name="medium_id" class="form-select" id="">
														<option value="">Add medium</option>
														<?php $__currentLoopData = $medium; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<option value="<?php echo e($data->id); ?>"><?php echo e($data->title); ?></option>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</select>
												</div>
												<div class="mb-3">
													<label for="recipient-name" class="col-form-label">lesson</label>
													<select name="lesson_id" class="form-select" id="">
														<option value="">Add lesson</option>
														<?php $__currentLoopData = $lesson; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<option value="<?php echo e($data->id); ?>"><?php echo e($data->title); ?></option>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</select>
												</div>
												<div class="mb-3">
													<label for="recipient-name" class="col-form-label">Subject</label>
													<select name="subject_id" class="form-select" id="">
														<option value="">add Subject</option>
														<?php $__currentLoopData = $subject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<option value="<?php echo e($data->id); ?>"><?php echo e($data->subject); ?></option>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</select>
												</div>

										</div>
										<div class="modal-footer">
											<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
											<button type="submit" name="submit" class="btn btn-primary">Save</button>
											</form>

										</div>
									</div>
								</div>
							</div>



							<div class="col-auto">
								<a class="btn app-btn-secondary" href="#">
									<svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-download me-1" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
										<path fill-rule="evenodd" d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z" />
										<path fill-rule="evenodd" d="M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708l3 3z" />
									</svg>
									Download Excel
								</a>
							</div>
						</div>
						<!--//row-->
					</div>
					<!--//table-utilities-->
				</div>
				<!--//col-auto-->
			</div>
	<div class="tab-content" id="orders-table-tab-content">
				<div class="tab-pane fade show active" id="orders-all" role="tabpanel" aria-labelledby="orders-all-tab">
					<div class="app-card app-card-orders-table shadow-sm mb-5">
						<div class="app-card-body">
							<div class="table-responsive">


								<?php if($message = Session::get('success')): ?>

								<div class="alert alert-success">

									<p><?php echo e($message); ?></p>

								</div>

								<?php endif; ?>


								<table class="table app-table-hover mb-0 text-left">
									<thead>
										<tr>
											<th class="cell">Id</th>
											<th class="cell">Question</th>
											<th class="cell">option 1</th>
											<th class="cell">option 2</th>
											<th class="cell">option 3</th>
											<th class="cell">option 4</th>
											<th class="cell">Answer</th>
											<th class="cell">Board</th>
											<th class="cell">Subject</th>
											<th class="cell">lesson</th>
											<th class="cell">Medium</th>
											<th class="cell">category</th>
											<th class="cell">Show</th>
											<th class="cell">Update</th>
											<th class="cell">Delete</th>

										</tr>
									</thead>

									<tbody>    <?php $i = 1;  ?>
										<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<tr>
											<td class="cell"><?php echo e($i++); ?></< /td>
											<td class="cell"><?php echo e($data->title); ?></td>
											<td class="cell"><?php echo e($data->option_1); ?></td>
											<td class="cell"><?php echo e($data->option_2); ?></td>
											<td class="cell"><?php echo e($data->option_3); ?></td>
											<td class="cell"><?php echo e($data->option_4); ?></td>
											<td class="cell"><?php echo e($data->answer); ?></td>
											<td class="cell"><?php echo e($data->board); ?></td>
											<td class="cell"><?php echo e($data->subject); ?></td>
											<td class="cell"><?php echo e($data->lesson); ?></td>
											<td class="cell"><?php echo e($data->medium); ?></td>
											<td class="cell"><?php echo e($data->category); ?></td>
											<td class="cell">
											<a data-toggle="modal" id="smallButton" data-target="#smallModal"
                                href="<?php echo e(route('question.show', $data->id)); ?>" title="show">
                               Show
                            </a>
											</td>



											<td class="cell">
												<a href="<?php echo e(route('question.edit',$data->id)); ?>">Update</a>
											</td>

											<form action="<?php echo e(route('question.destroy',$data->id)); ?>" method="POST">
												<?php echo csrf_field(); ?>
												<?php echo method_field('DELETE'); ?>
												<td class="cell"><button type="submit" onclick="return confirm(' you want to delete?');" class="btn btn-danger">Delete</button></td>
											</form>
										</tr>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</tbody>
								</table>
							</div>
							<!--//table-responsive-->
						</div>
						<!--//app-card-body-->
					</div>
					<!--//app-card-->
				</div>
				<!--//tab-pane-->




				<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <!-- Script -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js' type='text/javascript'></script>


				<!-- small modal -->
				<div class="modal fade" id="smallModal" tabindex="-1" role="dialog" aria-labelledby="smallModalLabel" aria-hidden="true">
					<div class="modal-dialog modal-sm" role="document">
						<div class="modal-content">
							<div class="modal-header">
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
							<div class="modal-body" id="smallBody">
								<div>
									<!-- the result to be displayed apply here -->
								</div>
							</div>
						</div>
					</div>
				</div>


				<!-- medium modal -->
				<div class="modal fade" id="mediumModal" tabindex="-1" role="dialog" aria-labelledby="mediumModalLabel" aria-hidden="true">
					<div class="modal-dialog" role="document">
						<div class="modal-content">
							<div class="modal-header">
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
							<div class="modal-body" id="mediumBody">
								<div>
									<!-- the result to be displayed apply here -->
								</div>
							</div>
						</div>
					</div>
				</div>


				<script>
					// display a modal (small modal)
					$(document).on('click', '#smallButton', function(event) {
						event.preventDefault();
						let href = $(this).attr('data-attr');
						$.ajax({
							url: href,
							beforeSend: function() {
								$('#loader').show();
							},
							// return the result
							success: function(result) {
								$('#smallModal').modal("show");
								$('#smallBody').html(result).show();
							},
							complete: function() {
								$('#loader').hide();
							},
							error: function(jqXHR, testStatus, error) {
								console.log(error);
								alert("Page " + href + " cannot open. Error:" + error);
								$('#loader').hide();
							},
							timeout: 8000
						})
					});
					// display a modal (medium modal)
					$(document).on('click', '#mediumButton', function(event) {
						event.preventDefault();
						let href = $(this).attr('data-attr');
						$.ajax({
							url: href,
							beforeSend: function() {
								$('#loader').show();
							},
							// return the result
							success: function(result) {
								$('#mediumModal').modal("show");
								$('#mediumBody').html(result).show();
							},
							complete: function() {
								$('#loader').hide();
							},
							error: function(jqXHR, testStatus, error) {
								console.log(error);
								alert("Page " + href + " cannot open. Error:" + error);
								$('#loader').hide();
							},
							timeout: 8000
						})
					});
				</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell\Downloads\madrasa\Madrasa\resources\views/question/index.blade.php ENDPATH**/ ?>