
<?php $__env->startSection('content'); ?>
    <div class="app-wrapper">
        <div class="app-content pt-3 p-md-3 p-lg-4">
            <div class="container-xl">
                <div class="row g-3 mb-4 align-items-center justify-content-between">
                    <div class="col-auto">
                        <h1 class="app-page-title mb-0">Naz Update</h1>
                    </div>
                    <div class="col-auto">
                        <div class="page-utilities">
                            <div class="row g-2 justify-content-start justify-content-md-end align-items-center">
                                <div class="col-auto">
                                    <style>
                                        input {
                                            text-transform: capitalize;
                                        }
                                        .cell {
                                            text-align: center;
                                        }
                                        th,
                                        td {
                                            text-transform: capitalize;
                                        }

                                    </style>
                                </div>
                            </div>
                        </div>
 </div>
</div>
<form action="<?php echo e(route('checknaz')); ?>" method="POST">
	<?php echo csrf_field(); ?>
	<?php echo method_field('post'); ?>
<label for="">Month</label>
	<select  class="form-select" name="month_id" id="">
		<?php $__currentLoopData = $daily_naz; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
		switch ($data->month) {
			case 1:
				$month = 'January';
				break;
			case 2:
				$month = 'February';
				break;
			case 3:
				$month = 'March';
				break;
			case 4:
				$month = 'April';
				break;
			case 5:
				$month = 'May';
				break;
			case 6:
				$month = 'June';
				break;
			case 7:
				$month = 'July';
				break;
			case 8:
				$month = 'August';
				break;
			case 9:
				$month = 'September';
				break;
			case 10:
				$month = 'October';
				break;
			case 11:
				$month = 'November';
				break;
		
			default:
				$month = 'December';
		}?>

			<option value="<?php echo e($data->month); ?>"><?php echo e($month); ?></option>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</select>
	<p></p>
	<label for="">Student</label>
	
		<select class="form-select" name="student_id" id="">
			<?php $__currentLoopData = $daily_naz; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<option value="<?php echo e($data->student_id); ?>"><?php echo e($data->name); ?></option>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			
		</select>
<button style="margin:4px 42%;" type="submit" class="btn btn-secondary" >Submit</button>

</form>
 <div class="tab-content" id="orders-table-tab-content">
                    <div class="tab-pane fade show active" id="orders-all" role="tabpanel" aria-labelledby="orders-all-tab">
                        <div class="app-card app-card-orders-table shadow-sm mb-5">
                            <div class="app-card-body">
                                <div class="table-responsive">
                                    <?php if($message = Session::get('success')): ?>
                                        <div class="alert alert-success">
                                            <p><?php echo e($message); ?></p>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <!--//table-responsive-->

                            </div>
                            <!--//app-card-body-->
                        </div>
                        <!--//app-card-->
                    </div>
                <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\madrasa\resources\views/paras/naz.blade.php ENDPATH**/ ?>