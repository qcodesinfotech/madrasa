
<?php $__env->startSection('content'); ?>

<head>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

</head>

<body>

  <div style="margin:0% 30%;">
    <h2>Exam Management</h2>
    <div class="form-group">
      <label for="country">board:</label>
      <select id="board" name="category_id" class="form-control">
        <option value="" selected disabled>Select Board</option>
        <?php if(isset($boards)): ?>
        <?php $__currentLoopData = $boards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $board): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($key); ?>"> <?php echo e($board); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
      </select>


      <!-- /////////////////////////////         -->

      <label for="medium">Medium:</label>
      <select name="medium" id="medium" class="form-control"></select>

      <!-- //////////////////////// -->
      <form action="<?php echo e(route('getquestion')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('POST'); ?>
      <label for="period">class:</label>
      <select name="period" id="period" class="form-control"></select>

      <!-- ////////////////////////////////// -->

      <label for="subject">subject:</label>
      <select name="subject" id="subject" class="form-control"></select>


      <!-- /////////////////////////////////// -->



  
        <label for="lession">lesson:</label>
        <select name="lesson" id="lesson" class="form-control"></select>


        <label for="category">Question category:</label>
        <select name="category" id="category" class="form-control"></select>
        <!-- /////////////////////////////////// -->


        <button style="margin:5%;" type="submit" name="submit" class="btn btn-success">Next</button>
      </form>


      

  <script type=text/javascript>
    $('#board').change(function() {
      var boardID = $(this).val();
      if (boardID) {
        $.ajax({
          type: "GET",
          url: "<?php echo e(url('getmedium')); ?>?board_id=" + boardID,
          success: function(res) {
            if (res) {
              $("#medium").empty();
              $("#medium").append('<option>Select Medium</option>');
              $.each(res, function(key, value) {
                $("#medium").append('<option value="' + key + '">' + value + '</option>');
              });
            } else {
              $("#medium").empty();
            }
          }
        });
      } else {
        $("#medium").empty();
        $("#period").empty();
      }
    });



    $('#medium').on('change', function() {
      var mediumID = $(this).val();
      if (mediumID) {
        $.ajax({
          type: "GET",
          url: "<?php echo e(url('getperiod')); ?>?medium_id=" + mediumID,
          success: function(res) {
            if (res) {
              $("#period").empty();
              $("#period").append('<option>Select Class</option>');
              $.each(res, function(key, value) {
                $("#period").append('<option value="' + key + '">' + value + '</option>');
              });

            } else {
              $("#period").empty();
            }
          }
        });
      } else {
        $("#period").empty();
      }

    });
    $('#period').on('change', function() {
      var periodID = $(this).val();
      if (periodID) {
        $.ajax({
          type: "GET",
          url: "<?php echo e(url('getsubject')); ?>?class_id=" + periodID,
          success: function(res) {
            if (res) {
              $("#subject").empty();
              $("#subject").append('<option>Select Subject</option>');
              $.each(res, function(key, value) {
                $("#subject").append('<option value="' + key + '">' + value + '</option>');
              });

            } else {
              $("#subject").empty();
            }
          }
        });
      } else {
        $("#subject").empty();
      }

    });

    $('#subject').on('change', function() {
      var subjectID = $(this).val();
      if (subjectID) {
        $.ajax({
          type: "GET",
          url: "<?php echo e(url('getlession')); ?>?subject_id=" + subjectID,
          success: function(res) {
            if (res) {
              $("#lesson").empty();
              $("#lesson").append('<option>Select Lesson</option>');
              $.each(res, function(key, value) {
                $("#lesson").append('<option value="' + key + '">' + value + '</option>');
              });

            } else {
              $("#lesson").empty();
            }
          }
        });
      } else {
        $("#lesson").empty();
      }

    });



    $('#lesson').on('change', function() {
      var lessonID = $(this).val();
      if (lessonID) {
        $.ajax({
          type: "GET",
          url: "<?php echo e(url('getcategory')); ?>?lesson_id=" + lessonID,
          success: function(res) {
            if (res) {
              $("#category").empty();
              $("#category").append('<option>Select Questuion Category</option>');
              $.each(res, function(key, value) {
                $("#category").append('<option value="' + key + '">' + value + '</option>');
              });

            } else {
              $("#category").empty();
            }
          }
        });
      } else {
        $("#category").empty();
      }

    });
  </script>
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Student-App\resources\views/question/exam.blade.php ENDPATH**/ ?>