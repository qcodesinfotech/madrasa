

<?php $__env->startSection('content'); ?>
<div class="app-wrapper">

	<div class="app-content pt-3 p-md-3 p-lg-4">
		<div class="container-xl">

			<div class="row g-3 mb-4 align-items-center justify-content-between">
				<div class="col-auto">
					<h1 class="app-page-title mb-0">School</h1>
				</div>
				<div class="col-auto">
					<div class="page-utilities">
						<div class="row g-2 justify-content-start justify-content-md-end align-items-center">
							<div class="col-auto">
								<form class="table-search-form row gx-1 align-items-center">
									<div class="col-auto">
										<input type="text" id="search-orders" name="searchorders" class="form-control search-orders" placeholder="Search">
									</div>
									<div class="col-auto">
										<button type="submit" class="btn app-btn-secondary">Search</button>
									</div>
								</form>

							</div>
							<!--//col-->
							<button type="button" onMouseOver="this.style.color='#15A362'" onMouseOut="this.style.color='#676778'" style="border-radius:5px;padding:4px;background-color:white;border:1px solid #676778;;color:#676778; " class="col-auto" data-bs-toggle="modal" data-bs-target="#exampleModal" data-bs-whatever="@getbootstrap">Add To school</button>

							<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
								<div class="modal-dialog">
									<div class="modal-content">
										<div class="modal-header">
											<h5 class="modal-title" id="exampleModalLabel">Add School</h5>
											<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
										</div>
										<div class="modal-body">
											<?php if($errors->any()): ?>

											<div class="alert alert-danger">

												<strong>Whoops!</strong> There were some problems with your input.<br><br>

												<ul>

													<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

													<li><?php echo e($error); ?></li>

													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

												</ul>

											</div>

											<?php endif; ?>
											<form action="<?php echo e(route('school.store')); ?>" method="POST">
												<?php echo csrf_field(); ?>



												<div class="mb-3">
													<label for="recipient-name" class="col-form-label">Location</label>
													<input type="hidden" name="updated" value="0" class="form-control" id="recipient-name">
													<select name="location_id" class="form-select" id="">
														<?php $__currentLoopData = $location; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<option value="<?php echo e($data->id); ?>"><?php echo e($data->city); ?></option>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</select>
												</div>

												<div class="mb-3">
													<label for="recipient-name" class="col-form-label">Door Number</label>
													<input type="text" name="door_number" class="form-control" id="recipient-name">

												</div>
												<div class="mb-3">
													<label for="recipient-name" class="col-form-label">Street</label>
													<input type="text" name="street" class="form-control" id="recipient-name">
												</div>


												<div class="mb-3">
													<label for="recipient-name" class="col-form-label">Board</label>
													<select name="board_id" class="form-select" id="">
														<?php $__currentLoopData = $board; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<option value="<?php echo e($data->id); ?>"><?php echo e($data ->title); ?></option>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</select>
												</div>

												<div class="mb-3">
													<label for="message-text" class="col-form-label">school Name:</label>
													<textarea class="form-control" name="school_name" id="message-text"></textarea>
												</div>

										</div>
										<div class="modal-footer">
											<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
											<button type="submit" name="submit" class="btn btn-primary">Save</button>
											</form>
										</div>
									</div>
								</div>
							</div>
							<div class="col-auto">
								<a class="btn app-btn-secondary" href="#">
									<svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-download me-1" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
										<path fill-rule="evenodd" d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z" />
										<path fill-rule="evenodd" d="M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708l3 3z" />
									</svg>
									Download CSV
								</a>
							</div>
						</div>
						<!--//row-->
					</div>
					<!--//table-utilities-->
				</div>
				<!--//col-auto-->
			</div>
			<!--//row-->
			<div class="tab-content" id="orders-table-tab-content">
				<div class="tab-pane fade show active" id="orders-all" role="tabpanel" aria-labelledby="orders-all-tab">
					<div class="app-card app-card-orders-table shadow-sm mb-5">
						<div class="app-card-body">
							<div class="table-responsive">
								<?php if($message = Session::get('success')): ?>

								<div class="alert alert-success">
									<p><?php echo e($message); ?></p>
								</div>
								<?php endif; ?>
								<table class="table app-table-hover mb-0 text-left">
									<thead>
										<tr>
											<th class="cell">Id</th>
											<th class="cell">Location</th>
											<th class="cell">Door Number</th>
											<th class="cell">Street</th>
											<th class="cell">School</th>
											<th class="cell">Board</th>
											<th class="cell">Created Date</th>
											<th class="cell">Updated Date</th>
											<th class="cell">Update</th>
											<th class="cell">Delete</th>

										</tr>
									</thead>
									<tbody>
										<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<tr>
											<td class="cell"><?php echo e(++$i); ?></td>
											<td class="cell"><?php echo e($data->city); ?></td>
											<td class="cell"><?php echo e($data->door_number); ?></td>
											<td class="cell"><?php echo e($data->street); ?></td>
											<td class="cell"><?php echo e($data->school_name); ?></td>
											<td class="cell"><?php echo e($data->title); ?></td>
											<td class="cell"><?php echo e($data->created_at); ?></td>
											<td class="cell"><?php echo e($data->updated_at); ?></td>
											<td class="cell">
											

												<a href="<?php echo e(route('school.edit', $data->id)); ?>">Update</a></td>


											</td>


											<form action="<?php echo e(route('school.destroy',$data->id)); ?>" method="POST">
												<?php echo csrf_field(); ?>

												<?php echo method_field('DELETE'); ?>

												<td class="cell"><button type="submit" onclick="return confirm(' you want to delete?');" class="btn btn-danger">Delete</button></td>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</form>
										</tr>
									</tbody>
								</table>

							</div>
							<!--//table-responsive-->

						</div>
						<!--//app-card-body-->
					</div>
					<!--//app-card-->
				</div>
				<!--//tab-pane-->


				<?php echo $school->links(); ?>

				<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Student-App 27-7\Student-App\resources\views/school/index.blade.php ENDPATH**/ ?>