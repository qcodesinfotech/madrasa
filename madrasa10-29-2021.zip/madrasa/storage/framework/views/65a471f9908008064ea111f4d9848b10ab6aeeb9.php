

<?php $__env->startSection('content'); ?>

<style>
	.form {
		margin-left: 30%;
		width: 50%;
		background-color: lightgray;
		padding: 5px 20px;
		border-radius: 6px;
	}

	label {
		text-align: center;
	}
</style>

<div class="form">
	<?php if($errors->any()): ?>
	<div class="alert alert-danger">
		<strong>Whoops!</strong> There were some problems with your input.<br><br>
		<ul>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li><?php echo e($error); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>
	<?php endif; ?>



<form action="<?php echo e(route('assign.update', $syllabi->id)); ?>" method="POST" enctype="multipart/form-data">

		<?php echo csrf_field(); ?>
		<?php echo method_field('PUT'); ?>
		<div class="mb-3">
			<label class="form-label" for="customFile">Name</label>
			<select name="name" class="form-select" id="" required>
                <option value="<?php echo e($syllabi->student_id); ?>"><?php echo e($syllabi->name); ?></option>
                <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($data->id); ?>"><?php echo e($data->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
			
			<label class="form-label" for="customFile">Course</label>
			<select name="course" class="form-select" id="" required>
                <option value="<?php echo e($syllabi->type_syllabus_id); ?>"><?php echo e($syllabi->syllabus_type); ?></option>
                <?php $__currentLoopData = $syllabus_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($data->id); ?>"><?php echo e($data->title); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

			<label class="form-label" for="customFile">Month</label>

			<select name="month" class="form-select" id="" required>
                <option value="<?php echo e($syllabi->month); ?>"><?php echo e($syllabi->months); ?></option>
                <?php $__currentLoopData = $month; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($data->id); ?>"><?php echo e($data->month); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
		
			<label class="form-label" for="customFile">Year</label>

			<select name="year" class="form-select" id="" required>
                <option value="<?php echo e($syllabi->year_id); ?>"><?php echo e($syllabi->course_year); ?></option>
                <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($data->id); ?>"><?php echo e($data->title); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

		</div>	
		
		<button style="margin-left:34%;" type="submit" class="btn btn-primary">Submit</button>
	</form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Madrasa\resources\views/assign/edit.blade.php ENDPATH**/ ?>